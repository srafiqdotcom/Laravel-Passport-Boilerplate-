<?php

return [
    'success' => 'success',
    'not_found' => 'Not found',
    'errors' => [
        'validation' => 'Validation error',
        'unexpected' => 'An unexpected error occurred. Please try again later.',
        'invalidCreds' => 'Invalid credentials.',

    ]
    ];
