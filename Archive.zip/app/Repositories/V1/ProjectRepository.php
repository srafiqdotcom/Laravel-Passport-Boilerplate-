<?php

namespace App\Repositories\V1;

use App\Utilities\ResponseHandler;
use Illuminate\Http\Request;
use App\Models\Projects;
use App\Models\Attributes;
use App\Models\AttributeValues;
use App\Utilities\FilterHelper;

class ProjectRepository extends BaseRepository
{
    protected string $logChannel;

    public function __construct(Request $request, Projects $projects)
    {
        parent::__construct($projects);
        $this->logChannel = 'projects_logs';
    }

    public function projectListing($request)
    {
        try {
            $query = $this->model::query();

            // Allowed regular columns on the projects table.
            $allowedColumns = ['name', 'status'];

            // Get filters from request (if provided)
            $filters = $request->input('filters', []);

            // Apply filters if any.
            if (!empty($filters)) {
                $query = FilterHelper::applyFilters($query, $filters, $allowedColumns);
            }

            // Load EAV attributes (assuming your Project model defines attributeValues relation)
            $projects = $query->with('attributeValues.attribute')->get();

            // Transform EAV data into a key-value array.
            $projects->transform(function ($project) {
                $dynamicAttributes = [];
                foreach ($project->attributeValues as $attrValue) {
                    $dynamicAttributes[$attrValue->attribute->name] = $attrValue->value;
                }
                $project->dynamic_attributes = $dynamicAttributes;
                unset($project->attributeValues);
                return $project;
            });

            return ResponseHandler::success($projects, __('common.success'));
        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500, 24);
        }
    }

    public function createProject(array $validatedRequest)
    {
        try {
            // Create the project
            $project = $this->model::create([
                'name' => $validatedRequest['name'],
                'status' => $data['status'] ?? null,
            ]);

            // Handle dynamic attributes if provided
            if (isset($data['attributes']) && is_array($data['attributes'])) {
                foreach ($data['attributes'] as $attrName => $attrValue) {
                    // Find or create the attribute (default type 'text'; adjust as needed)
                    $attribute = Attributes::firstOrCreate(
                        ['name' => $attrName],
                        ['type' => 'text']
                    );

                    // Create an attribute value for the project
                    AttributeValues::create([
                        'attribute_id' => $attribute->id,
                        'entity_id' => $project->id,
                        'value' => $attrValue,
                    ]);
                }
            }

            // Reload the project with dynamic attributes
            $project->load('attributeValues.attribute');
            $dynamicAttributes = [];
            foreach ($project->attributeValues as $attrValue) {
                $dynamicAttributes[$attrValue->attribute->name] = $attrValue->value;
            }
            $project->dynamic_attributes = $dynamicAttributes;
            unset($project->attributeValues);

            return ResponseHandler::success($project, __('common.success'));

        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500, 26);
        }
    }

    public function showProject(array $validatedRequest)
    {
        try {

            $project = $this->model::with('attributeValues.attribute')->find($validatedRequest['id']);
            if (!$project) {
                return ResponseHandler::error(__('common.not_found'), 404, 2005);
            }

            $dynamicAttributes = [];
            foreach ($project->attributeValues as $attrValue) {
                $dynamicAttributes[$attrValue->attribute->name] = $attrValue->value;
            }
            $project->dynamic_attributes = $dynamicAttributes;
            unset($project->attributeValues);
            return ResponseHandler::success($project, __('common.success'));

        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500, 26);
        }
    }

    public function updateProject(array $validatedRequest)
    {
        try {
            $project = $this->model::find($validatedRequest['id']);
            if (!$project) {
                return ResponseHandler::error(__('common.not_found'), 404, 2009);
            }

            // Update project fields
            $project->update([
                'name' => $data['name'] ?? $project->name,
                'status' => $data['status'] ?? $project->status,
            ]);

            // Update or create dynamic attributes if provided
            if (isset($data['attributes']) && is_array($data['attributes'])) {
                foreach ($data['attributes'] as $attrName => $attrValue) {
                    $attribute = Attributes::firstOrCreate(
                        ['name' => $attrName],
                        ['type' => 'text']
                    );

                    $attributeValue = AttributeValues::where('attribute_id', $attribute->id)
                        ->where('entity_id', $project->id)
                        ->first();

                    if ($attributeValue) {
                        $attributeValue->update(['value' => $attrValue]);
                    } else {
                        AttributeValues::create([
                            'attribute_id' => $attribute->id,
                            'entity_id' => $project->id,
                            'value' => $attrValue,
                        ]);
                    }
                }
            }

            // Reload project with dynamic attributes
            $project->load('attributeValues.attribute');
            $dynamicAttributes = [];
            foreach ($project->attributeValues as $attrValue) {
                $dynamicAttributes[$attrValue->attribute->name] = $attrValue->value;
            }
            $project->dynamic_attributes = $dynamicAttributes;
            unset($project->attributeValues);
            return ResponseHandler::success($project, __('common.success'));

        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500, 26);
        }
    }

    public function deleteProject(array $validatedRequest)
    {
        try {
            $project = $this->model::find($validatedRequest['id']);
            $project->delete();
            return ResponseHandler::success([], __('common.success'));

        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500, 26);
        }
    }
}
