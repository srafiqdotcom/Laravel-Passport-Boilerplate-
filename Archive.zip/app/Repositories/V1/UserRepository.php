<?php

namespace App\Repositories\V1;

use App\Models\User;
use App\Utilities\ResponseHandler;
use Illuminate\Http\Request;
use App\Models\Projects;
use App\Utilities\FilterHelper;

class UserRepository extends BaseRepository
{
    protected string $logChannel;

    public function __construct(Request $request, Projects $projects)
    {
        parent::__construct($projects);
        $this->logChannel = 'user_logs';
    }

    public function userListing($request)
    {
        try {
            $query = $this->model::query();

            // Allowed regular columns on the projects table.
            $allowedColumns = ['name', 'status'];

            // Get filters from request (if provided)
            $filters = $request->input('filters', []);

            // Apply filters if any.
            if (!empty($filters)) {
                $query = FilterHelper::applyFilters($query, $filters, $allowedColumns);
            }

            // Load EAV attributes (assuming your Project model defines attributeValues relation)
            $projects = $query->with('attributeValues.attribute')->get();

            // Transform EAV data into a key-value array.
            $projects->transform(function ($project) {
                $dynamicAttributes = [];
                foreach ($project->attributeValues as $attrValue) {
                    $dynamicAttributes[$attrValue->attribute->name] = $attrValue->value;
                }
                $project->dynamic_attributes = $dynamicAttributes;
                unset($project->attributeValues);
                return $project;
            });

            return ResponseHandler::success($projects, __('common.success'));
        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500, 24);
        }
    }

    public function createUser(array $validatedRequest)
    {
        try {
            // Create the project
            $user = $this->model::create($validatedRequest);
            return ResponseHandler::success($user, __('common.success'));

        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500, 26);
        }
    }

    public function showUser(array $validatedRequest)
    {
        try {

            $user = $this->model::find($validatedRequest['id']);

            if (!$user) {
                return ResponseHandler::error(__('common.not_found'), 404, 3005);
            }

            return ResponseHandler::success($user, __('common.success'));

        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500, 26);
        }
    }


    public function deleteUser(array $validatedRequest)
    {
        try {
            $user = $this->model::find($validatedRequest['id']);
            if (!$user) {
                return ResponseHandler::error(__('common.not_found'), 404, 3015);
            }
            $user->delete();
            return ResponseHandler::success([], __('common.success'));
        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500, 26);
        }
    }
}
