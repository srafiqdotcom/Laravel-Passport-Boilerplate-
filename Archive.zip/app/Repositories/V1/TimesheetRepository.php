<?php

namespace App\Repositories\V1;

use App\Models\User;
use App\Utilities\ResponseHandler;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;


class TimesheetRepository extends BaseRepository
{
    protected string $logChannel;

    public function __construct(Request $request, User $user)
    {
        parent::__construct($user);
        $this->logChannel = 'timesheet_logs';
    }

    public function createTimesheet(array $validatedRequest)
    {
        try {
            $user = $this->model::create($validatedRequest);

            return ResponseHandler::success($user, __('common.success'));
        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500,14);
        }
    }
    public function showTimesheet(array $validatedRequest)
    {
        try {
            $timesheet = $this->model::find($validatedRequest['id']);
            if (!$timesheet) {
                return ResponseHandler::error(__('common.not_found'), 404, 1004);
            }
            return ResponseHandler::success($timesheet, __('common.success'));
        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500,14);
        }
    }

    public function deleteTimesheet(array $validatedRequest)
    {
        try {
            $timesheet = $this->model::find($validatedRequest['id']);
            if (!$timesheet) {
                return ResponseHandler::error(__('common.not_found'), 404, 5015);
            }
            $timesheet->delete();
            return ResponseHandler::success([], __('common.success'));
        } catch (\Exception $e) {
            $this->logData($this->logChannel, $this->prepareExceptionLog($e), 'error');
            return ResponseHandler::error($this->prepareExceptionLog($e), 500, 26);
        }
    }
}
