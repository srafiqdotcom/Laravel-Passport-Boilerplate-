<?php

namespace App\Repositories\V2;

class BaseRepository
{
    public function __construct()
    {

    }


}
