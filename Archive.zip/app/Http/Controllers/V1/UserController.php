<?php

namespace App\Http\Controllers\V1;

use App\Http\Controllers\Controller as Controller;
use App\Models\User;
use App\Utilities\ResponseHandler;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Repositories\V1\UserRepository;
use stdClass;

class UserController extends Controller
{
    protected UserRepository $userRepository;

    /**
     * AuthController constructor.
     *
     * @param UserRepository $userRepository
     * @param Request $request
     */
    public function __construct(UserRepository $userRepository, Request $request)
    {
        parent::__construct($request);
        $this->userRepository = $userRepository;
    }
    /**
     * Display a listing of the resource.
     * GET /api/users
     */
    public function index(Request $request)
    {
        return $this->userRepository->userListing($request);
    }

    /**
     * Store a newly created resource in storage.
     * POST /api/users
     */
    public function store(Request $request)
    {
        $rules = [
            'first_name' => 'required|string',
            'last_name'  => 'required|string',
            'email'      => 'required|email|unique:users,email',
            'password'   => 'required|min:6',
        ];

        $validated = $this->validated($rules, $request->all());
        if ($validated->fails()) {
            return ResponseHandler::error(__('common.errors.validation'), 422, 2001, $validated->errors());
        }
        $validatedData = $validated->validated();
        // Hash the password before db interpretation
        $validated['password'] = Hash::make($validated['password']);

        return $this->userRepository->createUser($validatedData);
    }

    /**
     * Display the specified resource.
     * GET /api/users/{id}
     */
    public function show($id, Request $request)
    {

        $request->merge(['id' => $id]);
        $rules = [
            'id'       => 'required|integer|exists:users,id',
        ];

        $validated = $this->validated($rules, $request->all());
        if ($validated->fails()) {
            return ResponseHandler::error(__('common.errors.validation'), 422, 3011, $validated->errors());
        }
        return $this->userRepository->showUser($validated->validated());
    }

    /**
     * Update the specified resource in storage.
     * PUT /api/users/{id}
     */
    public function update(Request $request, string $id)
    {
        $user = User::find($id);
        if (!$user) {
            return ResponseHandler::error(__('common.not_found'), 404, 3012);
        }

        $rules = [
            'first_name' => 'sometimes|required|string',
            'last_name'  => 'sometimes|required|string',
            'email'      => 'sometimes|required|email|unique:users,email,' . $user->id,
            'password'   => 'sometimes|required|min:6',
        ];

        $validated = $this->validated($rules, $request->all());
        if ($validated->fails()) {
            return ResponseHandler::error(__('common.errors.validation'), 422, 3001, $validated->errors());
        }

        $validatedData = $validated->validated();
        // Hash the password before db interpretation
        if (isset($validatedData['password'])) {
            $validatedData['password'] = Hash::make($validatedData['password']);
        }
        $user->update($validatedData);
        return ResponseHandler::success($user, __('common.success'));
    }

    /**
     * Remove the specified resource from storage.
     * DELETE /api/users/{id}
     */
    public function destroy(string $id, Request $request)
    {
        $request->merge(['id' => $id]);
        $rules = [
            'id'       => 'required|integer|exists:users,id',
        ];

        $validated = $this->validated($rules, $request->all());
        if ($validated->fails()) {
            return ResponseHandler::error(__('common.errors.validation'), 422, 3011, $validated->errors());
        }
        return $this->userRepository->deleteUser($validated->validated());

    }
}
